Folder by: WINWINDACAT. Modded by: ______.

USAGE - You may use a modified version of this prank folder and upload it,
or use this or a modified version and upload images/videos online,
all assuming you credit WINWINDACAT.

Rename these files however you please, but please do not distribute 
unmodified copies of this folder online.

The "Free Robux" zip file (with a space) is a simple looping text box.
You can change the text displayed by opening with notepad.
The "FreeRobux" (no space) zip file is just a zip file that contains the FreeRobux (No Space) Batch file.
Use it to bypass Discord's system to view code in files to avoid malware.
It is harmless and only crashes or freezes your computer via browser tab overload.
P.S. If you edit with notepad then you can change the site it sends you to.
The "FreeRobux (Extract all)" Zip file is an INSANELY HUGE zipbomb.
(Approx. Three hundred SEPTILLION Y O T T A B Y T E S)
WARNING - USE THIS AT YOUR OWN RISK!!!

Have fun and adding files to upload is reccommended!